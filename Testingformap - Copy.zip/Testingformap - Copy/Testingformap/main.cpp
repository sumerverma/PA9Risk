#include <SFML/Graphics.hpp>
#include <iostream>
#include "circle.h"

using std::cin;
using std::cout;
using std::endl;
int main(void)
{
	sf::RenderWindow window(sf::VideoMode(2500, 1500), "MAP");

	section s1(sf::Color::Red, sf::Vector2f(10, 50), sf::Vector2f(0, 0));

	
	int tester = 0;

	int direction = 1;

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			window.close();
		}

		if (tester == 1)
		{
			s1.setFillColor(sf::Color::Blue);
		}
		window.clear();

		window.draw(s1);

		window.display();


	}

	return 0;
}






//MENU.CPP	
//#include "Menu.h"
//
//
//Menu::Menu(float width, float height)
//{
//	if (!font.loadFromFile("arial.ttf"))
//	{
//		// handle error
//	}
//
//	menu[0].setFont(font);
//	menu[0].setColor(sf::Color::Red);
//	menu[0].setString("Play");
//	menu[0].setPosition(sf::Vector2f(width / 2, height / (MAX_NUMBER_OF_ITEMS + 1) * 1));
//
//	menu[1].setFont(font);
//	menu[1].setColor(sf::Color::White);
//	menu[1].setString("Options");
//	menu[1].setPosition(sf::Vector2f(width / 2, height / (MAX_NUMBER_OF_ITEMS + 1) * 2));
//
//	menu[2].setFont(font);
//	menu[2].setColor(sf::Color::White);
//	menu[2].setString("Exit");
//	menu[2].setPosition(sf::Vector2f(width / 2, height / (MAX_NUMBER_OF_ITEMS + 1) * 3));
//
//	selectedItemIndex = 0;
//}
//
//
//Menu::~Menu()
//{
//}
//
//void Menu::draw(sf::RenderWindow &window)
//{
//	for (int i = 0; i < MAX_NUMBER_OF_ITEMS; i++)
//	{
//		window.draw(menu[i]);
//	}
//}
//
//void Menu::MoveUp()
//{
//	if (selectedItemIndex - 1 >= 0)
//	{
//		menu[selectedItemIndex].setColor(sf::Color::White);
//		selectedItemIndex--;
//		menu[selectedItemIndex].setColor(sf::Color::Red);
//	}
//}
//
//void Menu::MoveDown()
//{
//	if (selectedItemIndex + 1 < MAX_NUMBER_OF_ITEMS)
//	{
//		menu[selectedItemIndex].setColor(sf::Color::White);
//		selectedItemIndex++;
//		menu[selectedItemIndex].setColor(sf::Color::Red);
//	}
//}


// inside MENU.h
//#pragma once
//#include "SFML/Graphics.hpp"
//
//#define MAX_NUMBER_OF_ITEMS 3
//
//class Menu
//{
//public:
//	Menu(float width, float height);
//	~Menu();
//
//	void draw(sf::RenderWindow &window);
//	void MoveUp();
//	void MoveDown();
//	int GetPressedItem() { return selectedItemIndex; }
//
//private:
//	int selectedItemIndex;
//	sf::Font font;
//	sf::Text menu[MAX_NUMBER_OF_ITEMS];
//
//};

//MAIN
//#include "SFML/Graphics.hpp"
//#include <iostream>
//#include "Menu.h"
//
//int main()
//{
//	sf::RenderWindow window(sf::VideoMode(600, 600), "SFML WORK!");
//
//	Menu menu(window.getSize().x, window.getSize().y);
//
//	while (window.isOpen())
//	{
//		sf::Event event;
//
//		while (window.pollEvent(event))
//		{
//			switch (event.type)
//			{
//			case sf::Event::KeyReleased:
//				switch (event.key.code)
//				{
//				case sf::Keyboard::Up:
//					menu.MoveUp();
//					break;
//
//				case sf::Keyboard::Down:
//					menu.MoveDown();
//					break;
//
//				case sf::Keyboard::Return:
//					switch (menu.GetPressedItem())
//					{
//					case 0:
//						std::cout << "Play button has been pressed" << std::endl;
//						break;
//					case 1:
//						std::cout << "Option button has been pressed" << std::endl;
//						break;
//					case 2:
//						window.close();
//						break;
//					}
//
//					break;
//				}
//
//				break;
//			case sf::Event::Closed:
//				window.close();
//
//				break;
//
//			}
//		}
//
//		window.clear();
//
//		menu.draw(window);
//
//		window.display();
//	}
//}









