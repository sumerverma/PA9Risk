#include <SFML/Graphics.hpp>
#include <iostream>


class section : public sf::RectangleShape
{
public:
	section(sf::Color newColor, sf::Vector2f const &size, sf::Vector2f const &pos)
	{
		this->setFillColor(newColor);
		this->setSize(size);
		this->setPosition(pos);
	}
};