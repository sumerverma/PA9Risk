#include "SectionNode.h"

SectionNode::SectionNode(int lab, int att, int def, int siz, char own) {
	label = lab;
	attackDice = att;
	defenceDice = def;
	size = siz;
	ownership = own;
	hasattacked = 0;
	adjNode1 = 0;
	adjNode2 = 0;
	adjNode3 = 0;
	adjNode4 = 0;
	adjNode5 = 0;
	adjNode6 = 0;

}


SectionNode::~SectionNode() 
{
}




//setters
void SectionNode::setattackDice(int newAttack) {
	attackDice = newAttack;
}
void SectionNode::setdefenceDice(int newDefense) {
	defenceDice = newDefense;
}
void SectionNode::setsize(int newSize) {
	size = newSize;
}
void SectionNode::setownership(char newOwner) {
	ownership = newOwner;
}
void SectionNode::sethasattacked(int num) {
	hasattacked = num;
}
void SectionNode::setadjNode1(int newNode) {
	adjNode1 = newNode;
}
void SectionNode::setadjNode2(int newNode) {
	adjNode2 = newNode;
}
void SectionNode::setadjNode3(int newNode) {
	adjNode3 = newNode;
}
void SectionNode::setadjNode4(int newNode) {
	adjNode4 = newNode;
}
void SectionNode::setadjNode5(int newNode) {
	adjNode5 = newNode;
}
void SectionNode::setadjNode6(int newNode) {
	adjNode6 = newNode;
}
// getters
int SectionNode::getattackDice() {
	return attackDice;
}
int SectionNode::getdefenceDice() {
	return defenceDice;
}
int SectionNode::getsize() {
	return size;
}
char SectionNode::getownership() {
	return ownership;
}
int SectionNode::gethasattacked() {
	return hasattacked;
}
int SectionNode::getlabel() {
	return label;
}
int SectionNode::getadjNode1() {
	return adjNode1;
}
int SectionNode::getadjNode2() {
	return adjNode2;
}
int SectionNode::getadjNode3() {
	return adjNode3;
}
int SectionNode::getadjNode4() {
	return adjNode4;
}
int SectionNode::getadjNode5() {
	return adjNode5;
}
int SectionNode::getadjNode6() {
	return adjNode6;
}
