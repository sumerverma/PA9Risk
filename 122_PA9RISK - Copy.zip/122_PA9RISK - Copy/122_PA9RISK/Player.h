#pragma once
#include "SectionNode.h"

using std::cout;
using std::cin;
using std::endl;

class Player {
public:
	//constructor
	Player(char color);
	//destructor
	~Player();
	
	void playerturn(SectionNode list[]);
	
	//dice roll
	int rollDice(int dice);
	//add dice
	void addDice(SectionNode list[]);
	//move dice
	void moveDice(SectionNode list[]);
	//attack
	void attack(SectionNode list[]);

	
private:
	char playerColor;
	int points;
};