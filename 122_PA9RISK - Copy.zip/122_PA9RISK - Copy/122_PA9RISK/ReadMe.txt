Team Members: Daniel Hazelton, Sumer Verma, Thomas Glouner, Hernan Nunez-Ortega
Lab section: 4 for all
TA: Alex Lao



