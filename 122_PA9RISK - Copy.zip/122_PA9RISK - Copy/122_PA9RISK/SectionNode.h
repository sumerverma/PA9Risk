#pragma once
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <stdlib.h>
#include <time.h>
#include <ctime>
#include <SFML/Graphics.hpp>

using sf::RectangleShape;
using namespace std;
using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::ifstream;
using std::ofstream;
using std::ios;

class SectionNode {
public:
	SectionNode(int lab,int att,int def,int siz,char own);
	~SectionNode();
	
	

	//setters
	void setattackDice(int newAttack);
	void setdefenceDice(int newDefense);
	void setsize(int newSize);
	void setownership(char newOwner);
	void sethasattacked(int num);
	void setadjNode1(int newNode);
	void setadjNode2(int newNode);
	void setadjNode3(int newNode);
	void setadjNode4(int newNode);
	void setadjNode5(int newNode);
	void setadjNode6(int newNode);
	
	//getters
	int getattackDice();
	int getdefenceDice();
	int getsize();
	char getownership();
	int gethasattacked();
	int getlabel();
	int getadjNode1();
	int getadjNode2();
	int getadjNode3();
	int getadjNode4();
	int getadjNode5();
	int getadjNode6();

	

private:
	int label;
	int attackDice;
	int defenceDice;
	int size;
	char ownership;
	int hasattacked;
	int adjNode1;//Clockwise
	int adjNode2;
	int adjNode3;
	int adjNode4;
	int adjNode5;
	int adjNode6;

};








