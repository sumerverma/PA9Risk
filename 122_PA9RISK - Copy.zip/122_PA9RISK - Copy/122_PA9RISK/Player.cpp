#include "Player.h"

//constructor
Player::Player(char color) {
	playerColor = color;
	points = 0;
}
//destructor
Player::~Player() {
	//transverse through linked list and delete nodes
}


void Player::playerturn(SectionNode list[]) {
	addDice(list);
	moveDice(list);
	attack(list);
}



//dice roll
int Player::rollDice(int dice) {
	
	int sum = 0;
	for (int i = 0; i <= dice; i++) {
		sum += rand() % 6 + 1;;
	}
	return sum;
}

//add dice
void Player::addDice(SectionNode list[]) {
	int total = 0;
	int sectionChoice = 0;
	int valid = 0;
	int add = 0;
	int atdice;
	char ownership;

	for (int i = 0; i <= 13; i++) {
		if (list[i].getownership() == playerColor) {
			total += list[i].getsize();
		}
	}
	while (total != 0) {
		valid = 0;
		while (valid != 1) {// select section and checks ownership matches
			cout << "You have " << total << " points left to add. Which section do you want to add to?" << endl;
			cin >> sectionChoice;
			ownership = list[sectionChoice - 1].getownership();
			if (ownership == playerColor) {
				valid = 1;
			}
			else { cout << "You do not own this section." << endl; }//is choice valid?
		}
		valid = 0;
		while (valid != 1) {//asks how many points to add and makes sure amount is valid
			cout << "How many points do you want to add?" << endl;
			cin >> add;
			if (add >= 0 && add <= total) {
				valid = 1;
			}
			else { cout << "That is an ivalid number of points." << endl; }//is choice valid?
		}
		//after the section is checked for ownership and the points added are 0<= add <= total
		atdice = list[sectionChoice - 1].getattackDice();
		atdice += add;
		list[sectionChoice - 1].setattackDice(atdice);
		total -= add;
	}

}

//place dice
void Player::moveDice(SectionNode list[]) {
	int choice;
	int done = 0;
	int from;
	int to;
	int move;
	while (done==0) {
		cout << "Would you like to move some attack points this turn? (1 for yes, 2 for no)" << endl;
		cin >> choice;
		if (choice == 1) {
			cout << "What owned section would you like to move from?" << endl;
			cin >> from;
			if (list[from - 1].getownership()==playerColor) {
				cout << "What owned section would you like to move the points to?" << endl;
				cin >> to;
				if (list[to - 1].getownership() == playerColor) {
					cout << "How many points do you want to move?" << endl;
					cin >> move;
					if (move >= 0 && move <= list[from - 1].getattackDice()) {
						list[from - 1].setattackDice(list[from - 1].getattackDice()-move);
						list[to - 1].setattackDice(list[to - 1].getattackDice() + move);
					}
					else { cout << "You do not own enough attack points" << endl; }
				}
				else{ cout << "You do not own this section" << endl; }
			}
			else{ cout << "You do not own this section" << endl; }
		}
		else {
			done = 1;
		}
	}
}
//attack
void Player::attack(SectionNode list[]) {
	int done = 0;
	int yesno;
	int from;
	int to;
	int attacknum;
	int defensenum;
	int num;
	int choice;
	int move;
	int adj=0;
	
	while (done == 0) {
		cout << "Would you like to attack this turn? (1 for yes, 2 for no)" << endl;
		cin >> yesno;
		if (yesno == 1) {
			cout << "What owned section would you like to attack from?" << endl;
			cin >> from;
			if (list[from - 1].gethasattacked() == 0) {

			if (list[from - 1].getownership() == playerColor) {
				cout << "What enemy section would you like to attack?" << endl;
				cin >> to;
				cout << list[to - 1].getadjNode1() << endl;
				cout << list[from - 1].getlabel() << endl;
				
				if (list[to - 1].getadjNode1() == list[from - 1].getlabel()) {
					adj = 1;
				}
				else if (list[to - 1].getadjNode2() == list[from - 1].getlabel()) {
					adj = 1;
				}
				else if (list[to - 1].getadjNode3() == list[from - 1].getlabel()) {
					adj = 1;
				}
				else if (list[to - 1].getadjNode4() == list[from - 1].getlabel()) {
					adj = 1;
				}
				else if (list[to - 1].getadjNode5() == list[from - 1].getlabel()) {
					adj = 1;
				}
				else if (list[to - 1].getadjNode6() == list[from - 1].getlabel()) {
					adj = 1;
				}
				else {
					cout << "Those sections are not connected." << endl;
				}
				
				if (list[to - 1].getownership() != playerColor && adj==1) {
					list[from - 1].sethasattacked(1);
					attacknum = rollDice(list[from - 1].getattackDice());
					defensenum = rollDice(list[to - 1].getattackDice() + list[to - 1].getdefenceDice());
					cout << "Attack value: " << attacknum << endl;
					cout << "Defense value: " << defensenum << endl;
					if (attacknum > defensenum) {
						cout << "The attack was a success!" << endl;
						list[to - 1].setownership(playerColor);
						num = attacknum - defensenum;
						num = attacknum / num;
						//maybe check if error
						list[from - 1].setattackDice(list[from - 1].getattackDice() - num);
						list[to - 1].setattackDice(0);
						cout << "Would you like to move attack points to the newly taken section? (1 for yes, 2 for no)" << endl;
						cin >> choice;
						if (choice = 1) {
							cout << "How many points do you want to move?" << endl;
							cin >> move;
							if (move >= 0 && move <= list[from - 1].getattackDice()) {
								list[from - 1].setattackDice(list[from - 1].getattackDice() - move);
								list[to - 1].setattackDice(list[to - 1].getattackDice() + move);
							}
							else { cout << "You do not own enough attack points" << endl; }
						}
					}
					else {
						cout << "The attack failed!" << endl;
					}
				}
				else { cout << "Error" << endl; }
			}
			else { cout << "You do not own this section" << endl; }
			}
			else { cout << "You have attacked with this section" << endl; }
		}
		else {
			done = 1;
		}
	}
}