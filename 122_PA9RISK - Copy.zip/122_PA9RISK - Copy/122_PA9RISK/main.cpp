#include "SectionNode.h"
#include "Player.h"



int main()
{	
	sf::RenderWindow window(sf::VideoMode(3000, 1500), "Map"); //name of window and how large it is.


	int active = 0;
	int count = 0;
	int gamenotover = 0;
	srand(time(NULL));


	SectionNode Sec1(1, 0, 8, 3, 'R');//left to right from map
	SectionNode Sec2(2, 0, 2, 1, 'G');//(label, attack,defense,size,color)
	SectionNode Sec3(3, 0, 2, 1, 'G');
	SectionNode Sec4(4, 0, 4, 2, 'G');
	SectionNode Sec5(5, 0, 2, 1, 'G');
	SectionNode Sec6(6, 0, 2, 1, 'G');
	SectionNode Sec7(7, 0, 8, 3, 'G');
	SectionNode Sec8(8, 0, 2, 1, 'G');
	SectionNode Sec9(9, 0, 2, 1, 'G');
	SectionNode Sec10(10, 0, 4, 2, 'G');
	SectionNode Sec11(11, 0, 2, 1, 'G');
	SectionNode Sec12(12, 0, 2, 1, 'G');
	SectionNode Sec13(13, 0, 8, 3, 'B');

	Sec1.setadjNode1(2);//set map up by pointing nodes to eachother
	Sec1.setadjNode2(3);
	Sec2.setadjNode1(5);
	Sec2.setadjNode2(4);
	Sec2.setadjNode3(1);
	Sec3.setadjNode1(1);
	Sec3.setadjNode2(4);
	Sec3.setadjNode3(6);
	Sec4.setadjNode1(2);
	Sec4.setadjNode2(7);
	Sec4.setadjNode3(3);
	Sec5.setadjNode1(8);
	Sec5.setadjNode2(7);
	Sec5.setadjNode3(2);
	Sec6.setadjNode1(3);
	Sec6.setadjNode2(7);
	Sec6.setadjNode3(9);
	Sec7.setadjNode1(5);
	Sec7.setadjNode2(8);
	Sec7.setadjNode3(10);
	Sec7.setadjNode4(9);
	Sec7.setadjNode5(6);
	Sec7.setadjNode6(4);
	Sec8.setadjNode1(11);
	Sec8.setadjNode2(7);
	Sec8.setadjNode3(5);
	Sec9.setadjNode1(7);
	Sec9.setadjNode2(12);
	Sec9.setadjNode3(6);
	Sec10.setadjNode1(11);
	Sec10.setadjNode2(12);
	Sec10.setadjNode3(7);
	Sec11.setadjNode1(13);
	Sec11.setadjNode2(10);
	Sec11.setadjNode3(8);
	Sec12.setadjNode1(10);
	Sec12.setadjNode2(13);
	Sec12.setadjNode3(9);
	Sec13.setadjNode1(11);
	Sec13.setadjNode2(12);

	SectionNode sectionArray[] = { Sec1,Sec2,Sec3,Sec4,Sec5,Sec6,Sec7,Sec8,Sec9,Sec10,Sec11,Sec12,Sec13 };//array of sections in order
	Player player1('R');//create players 1 and 2
	Player player2('B');


	cout << "Rules of ISKR: This is a turn based strategy game.\n The board is split into sections, each section contains an attack and defense number" << endl;
	cout << "The objective of the game is to capture the enemy starting point.\n The game starts with each player having a 50 50 chance of starting first." << endl;
	cout << "The first player starts by adding reserve points to there section.\n These reserve points are based on how many sections owned and the size of these owned sections." << endl;
	cout << "Plus one for small, plus two for medium, and plus three for large.\n The player can choose to move some or all of their attack dice from one section to another section." << endl;
	cout << "The player can choose to attack an enemy or nuetral section.\n You can only attack one section per turn. During an attack the players attack points act as six sided die." << endl;
	cout << "The defending sections defend the attack by rolling both their attack and defense dice.\n Whichever sections rolls the highest total, wins." << endl;
	cout << "As the game goes on the attack stat will increase by one after both players have taken a turn.\n This will continue on until the enemy base is captured." << endl;
	cout << "Let's get started!" << endl;

	system("pause");
	system("cls");

	//Insert between 1 and 2
	active += rand() % 2 + 1;;
	if (active == 1) {
		cout << "Player 1 goes first." << endl;
	}
	if (active == 2) {
		cout << "Player 2 goes first." << endl;
	}



/*~~~~~~~~~~~~~~~~TEXT/Stats~~~~~~~~~~~~~~~~~~~*/
	sf::Font font;
	if (!font.loadFromFile("arial.ttf"))
	{
		std::cout << "Not loaded" << std::endl;
		//error
	}

	/*~~~~~~~~~~~~~~~~~~~~~LABELS~~~~~~~~~~~~~~~~~~~~~*/
	sf::String label("1");
	sf::Text label1(label, font, 50);
	label1.setPosition(0, 0);

	sf::String labelTwo("2");
	sf::Text label2(labelTwo, font, 50);
	label2.setPosition(515, 100);

	sf::String labelThree("3");
	sf::Text label3(labelThree, font, 50);
	label3.setPosition(150, 400);

	sf::String labelFour("4");
	sf::Text label4(labelFour, font, 50);
	label4.setPosition(400, 370);

	sf::String labelFive("5");
	sf::Text label5(labelFive, font, 50);
	label5.setPosition(690, 310);

	sf::String labelSix("6");
	sf::Text label6(labelSix, font, 50);
	label6.setPosition(150, 710);

	sf::String labelSeven("7");
	sf::Text label7(labelSeven, font, 50);
	label7.setPosition(580, 800);

	sf::String labelEight("8");
	sf::Text label8(labelEight, font, 50);
	label8.setPosition(1200, 420);

	sf::String labelNine("9");
	sf::Text label9(labelNine, font, 50);
	label9.setPosition(260, 1230);

	sf::String labelT("10");
	sf::Text label10(labelT, font, 50);
	label10.setPosition(1320, 950);

	sf::String labelLeven("11");
	sf::Text label11(labelLeven, font, 50);
	label11.setPosition(1680, 550);

	sf::String labelTwelve("12");
	sf::Text label12(labelTwelve, font, 50);
	label12.setPosition(1140, 1250);

	sf::String labelThirt("13");
	sf::Text label13(labelThirt, font, 50);
	label13.setPosition(1755, 1000);

	//text

	sf::String sentence("ISKR");
	sf::Text text(sentence, font, 100);

	text.setColor(sf::Color::Red);
	text.setPosition(1000, 35);

	//node1-main red
	sf::String n1A("Attack:");
	sf::Text n1a(n1A, font, 30);
	n1a.setColor(sf::Color::Black);
	n1a.setPosition(120, 170);

	sf::String n1D("Defense: 8");
	sf::Text n1d(n1D, font, 30);
	n1d.setColor(sf::Color::Black);
	n1d.setPosition(120, 220);

	//node2-small
	sf::String n2A("Attack:");
	sf::Text n2a(n2A, font, 20);
	n2a.setColor(sf::Color::Black);
	n2a.setPosition(580, 200);

	sf::String n2D("Defense: 2");
	sf::Text n2d(n2D, font, 20);
	n2d.setColor(sf::Color::Black);
	n2d.setPosition(570, 230);

	//node3-small
	sf::String n3A("Attack:");
	sf::Text n3a(n3A, font, 20);
	n3a.setColor(sf::Color::Black);
	n3a.setPosition(60, 500);
	sf::String n3D("Defense: 2");
	sf::Text n3d(n3D, font, 20);
	n3d.setColor(sf::Color::Black);
	n3d.setPosition(50, 525);

	//node4- medium
	sf::String n4A("Attack:");
	sf::Text n4a(n4A, font, 20);
	n4a.setColor(sf::Color::Black);
	n4a.setPosition(420, 520);

	sf::String n4D("Defense: 4");
	sf::Text n4d(n4D, font, 20);
	n4d.setColor(sf::Color::Black);
	n4d.setPosition(410, 545);

	//node5-small
	sf::String n5A("Attack:");
	sf::Text n5a(n5A, font, 20);
	n5a.setColor(sf::Color::Black);
	n5a.setPosition(770, 400);
	sf::String n5D("Defense: 2");
	sf::Text n5d(n5D, font, 20);
	n5d.setColor(sf::Color::Black);
	n5d.setPosition(760, 420);

	//node6-small
	sf::String n6A("Attack:");
	sf::Text n6a(n6A, font, 20);
	n6a.setColor(sf::Color::Black);
	n6a.setPosition(80, 850);

	sf::String n6D("Defense: 2");
	sf::Text n6d(n6D, font, 20);
	n6d.setColor(sf::Color::Black);
	n6d.setPosition(70, 870);

	//node7-large
	sf::String n7A("Attack:");
	sf::Text n7a(n7A, font, 30);
	n7a.setColor(sf::Color::Black);
	n7a.setPosition(760, 890);

	sf::String n7D("Defense: 8");
	sf::Text n7d(n7D, font, 30);
	n7d.setColor(sf::Color::Black);
	n7d.setPosition(750, 920);

	//node8-small
	sf::String n8A("Attack:");
	sf::Text n8a(n8A, font, 20);
	n8a.setColor(sf::Color::Black);
	n8a.setPosition(1225, 540);

	sf::String n8D("Defense: 2");
	sf::Text n8d(n8D, font, 20);
	n8d.setColor(sf::Color::Black);
	n8d.setPosition(1220, 560);

	//node9-small
	sf::String n9A("Attack:");
	sf::Text n9a(n9A, font, 20);
	n9a.setColor(sf::Color::Black);
	n9a.setPosition(385, 1300);

	sf::String n9D("Defense: 2");
	sf::Text n9d(n9D, font, 20);
	n9d.setColor(sf::Color::Black);
	n9d.setPosition(380, 1330);

	//node10-medium
	sf::String n10A("Attack:");
	sf::Text n10a(n10A, font, 20);
	n10a.setColor(sf::Color::Black);
	n10a.setPosition(1350, 1090);

	sf::String n10D("Defense: 4");
	sf::Text n10d(n10D, font, 20);
	n10d.setColor(sf::Color::Black);
	n10d.setPosition(1325, 1120);

	//node11-small
	sf::String n11A("Attack:");
	sf::Text n11a(n11A, font, 20);
	n11a.setColor(sf::Color::Black);
	n11a.setPosition(1040, 1350);

	sf::String n11D("Defense: 2");
	sf::Text n11d(n11D, font, 20);
	n11d.setColor(sf::Color::Black);
	n11d.setPosition(1030, 1370);

	//node12- small
	sf::String n12A("Attack:");
	sf::Text n12a(n12A, font, 20);
	n12a.setColor(sf::Color::Black);
	n12a.setPosition(1740, 650);

	sf::String n12D("Defense: 2");
	sf::Text n12d(n12D, font, 20);
	n12d.setColor(sf::Color::Black);
	n12d.setPosition(1730, 670);

	//node13-large main blue
	sf::String n13A("Attack:");
	sf::Text n13a(n13A, font, 30);
	n13a.setColor(sf::Color::Black);
	n13a.setPosition(1875, 1150);

	sf::String n13D("Defense: 8");
	sf::Text n13d(n13D, font, 30);
	n13d.setColor(sf::Color::Black);
	n13d.setPosition(1870, 1180);

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~CIRCLES~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	sf::CircleShape redMain(175.f);
	redMain.setPosition(0, 0);
	redMain.setFillColor(sf::Color(255, 0, 0));//this is the Main base for the red player.

	sf::CircleShape nuetral1(75.f);
	nuetral1.setPosition(15, 450);

	sf::CircleShape nuetral2(115.f);//medium center piece that is directly in front of reds main.
	nuetral2.setPosition(350, 450);
	//nuetral2.setFillColor(sf::Color::Red); 

	sf::CircleShape nuetral3(75.f);
	nuetral3.setPosition(550, 150);


	sf::CircleShape nuetral4(75.f);
	nuetral4.setPosition(750, 350);

	sf::CircleShape bigMiddle(175.f);//large middle 
	bigMiddle.setPosition(650, 750);

	sf::CircleShape nuetral6(75.f);
	nuetral6.setPosition(50, 800);

	sf::CircleShape nuetral7(75.f);
	nuetral7.setPosition(350, 1250);

	sf::CircleShape nuetral8(75.f);
	nuetral8.setPosition(1200, 500);//length,height

	sf::CircleShape nuetral9(75.f);
	nuetral9.setPosition(1700, 600);

	sf::CircleShape nuetral10(115.f);//last medium
	nuetral10.setPosition(1300, 1000);

	sf::CircleShape nuetral11(75.f);
	nuetral11.setPosition(1000, 1300);

	sf::CircleShape nuetral12(175.f);//blue main
	nuetral12.setPosition(1800, 1000);
	nuetral12.setFillColor(sf::Color::Blue);

	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~lines~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	sf::RectangleShape line;
	line.setSize(sf::Vector2f(200, 3));
	line.setPosition(350, 200);

	sf::RectangleShape line2;//LINE2
	line2.setSize(sf::Vector2f(3, 110));
	line2.setPosition(150, 350);
	line2.rotate(25);

	sf::RectangleShape line3;//LINE3
	line3.setSize(sf::Vector2f(190, 3));
	line3.setPosition(165, 520);

	sf::RectangleShape line4;
	line4.setSize(sf::Vector2f(3, 202));
	line4.setPosition(90, 600);
	line4.rotate(-8);

	RectangleShape line5;
	line5.setSize(sf::Vector2f(455, 3));//length,height
	line5.setPosition(200, 890);

	RectangleShape line6;
	line6.setSize(sf::Vector2f(3, 186));
	line6.setPosition(580, 285);
	line6.rotate(25);

	RectangleShape line7;
	line7.setSize(sf::Vector2f(145, 3));
	line7.setPosition(700, 250);
	line7.rotate(45);

	RectangleShape line8;
	line8.setSize(sf::Vector2f(3, 220));
	line8.setPosition(548, 645);
	line8.rotate(-40);

	RectangleShape line9;
	line9.setSize(sf::Vector2f(3, 250));
	line9.setPosition(825, 500);

	RectangleShape line10;
	line10.setSize(sf::Vector2f(3, 390));
	line10.setPosition(160, 945);
	line10.rotate(-34);

	RectangleShape line11;
	line11.setSize(sf::Vector2f(3, 320));
	line11.setPosition(680, 1020);
	line11.rotate(40);

	RectangleShape line12;
	line12.setSize(sf::Vector2f(325, 3));
	line12.setPosition(895, 450);
	line12.rotate(20);

	RectangleShape line13;
	line13.setSize(sf::Vector2f(3, 320));
	line13.setPosition(1220, 625);
	line13.rotate(50);


	RectangleShape line14;
	line14.setSize(sf::Vector2f(330, 3));
	line14.setPosition(995, 975);
	line14.rotate(15);

	RectangleShape line15;
	line15.setSize(sf::Vector2f(500, 3));
	line15.setPosition(500, 1350);
	line15.rotate(3);

	RectangleShape line16;
	line16.setSize(sf::Vector2f(364, 3));
	line16.setPosition(1350, 570);
	line16.rotate(12);

	RectangleShape line17;
	line17.setSize(sf::Vector2f(675, 3));
	line17.setPosition(1150, 1375);
	line17.rotate(-12);

	RectangleShape line18;
	line18.setSize(sf::Vector2f(245, 3));
	line18.setPosition(1145, 1350);
	line18.rotate(-35);

	RectangleShape line19;
	line19.setSize(sf::Vector2f(380, 3));
	line19.setPosition(1484, 1025);
	line19.rotate(-50);

	RectangleShape line20;
	line20.setSize(sf::Vector2f(3, 290));
	line20.setPosition(1800, 745);
	line20.rotate(-20);


	

	while (window.isOpen())
	{


		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}

		window.clear();

		window.draw(redMain);
		window.draw(nuetral1);
		window.draw(nuetral2);
		window.draw(nuetral3);
		window.draw(nuetral4);
		window.draw(bigMiddle);
		window.draw(nuetral6);
		window.draw(nuetral7);
		window.draw(nuetral8);
		window.draw(nuetral9);
		window.draw(nuetral10);
		window.draw(nuetral11);
		window.draw(nuetral12);

		//Stats for each area
		text.setString(sentence);
		window.draw(text);

		n1a.setString(n1A);
		window.draw(n1a);
		n1d.setString(n1D);
		window.draw(n1d);

		n2a.setString(n2A);
		window.draw(n2a);
		n2d.setString(n2D);
		window.draw(n2d);

		n3a.setString(n3A);
		window.draw(n3a);
		n3d.setString(n3D);
		window.draw(n3d);

		n4a.setString(n4A);
		window.draw(n4a);
		n4d.setString(n4D);
		window.draw(n4d);

		n5a.setString(n5A);
		window.draw(n5a);
		n5d.setString(n5D);
		window.draw(n5d);

		n6a.setString(n6A);
		window.draw(n6a);
		n6d.setString(n6D);
		window.draw(n6d);

		n7a.setString(n7A);
		window.draw(n7a);
		n7d.setString(n7D);
		window.draw(n7d);

		n8a.setString(n8A);
		window.draw(n8a);
		n8d.setString(n8D);
		window.draw(n8d);

		n9a.setString(n9A);
		window.draw(n9a);
		n9d.setString(n9D);
		window.draw(n9d);

		n10a.setString(n10A);
		window.draw(n10a);
		n10d.setString(n10D);
		window.draw(n10d);

		n11a.setString(n11A);
		window.draw(n11a);
		n11d.setString(n11D);
		window.draw(n11d);

		n12a.setString(n12A);
		window.draw(n12a);
		n12d.setString(n12D);
		window.draw(n12d);

		n13a.setString(n13A);
		window.draw(n13a);
		n13d.setString(n13D);
		window.draw(n13d);


		//lines
		window.draw(line);
		window.draw(line2);
		window.draw(line3);
		window.draw(line4);
		window.draw(line5);
		window.draw(line6);
		window.draw(line7);
		window.draw(line8);
		window.draw(line9);
		window.draw(line10);
		window.draw(line11);
		window.draw(line12);
		window.draw(line13);
		window.draw(line14);
		window.draw(line15);
		window.draw(line16);
		window.draw(line17);
		window.draw(line18);
		window.draw(line19);
		window.draw(line20);

		//LABELS
		label1.setString(label);
		window.draw(label1);

		label2.setString(labelTwo);
		window.draw(label2);

		label3.setString(labelThree);
		window.draw(label3);

		label4.setString(labelFour);
		window.draw(label4);
		
		label5.setString(labelFive);
		window.draw(label5);

		label6.setString(labelSix);
		window.draw(label6);

		label7.setString(labelSeven);
		window.draw(label7);

		label8.setString(labelEight);
		window.draw(label8);

		label9.setString(labelNine);
		window.draw(label9);

		label10.setString(labelT);
		window.draw(label10);

		label11.setString(labelLeven);
		window.draw(label11);

		label12.setString(labelTwelve);
		window.draw(label12);

		label13.setString(labelThirt);
		window.draw(label13);

		window.display();
		while (gamenotover == 0) {

			if (active == 1) {
				cout << "Player 1's turn" << endl;
				player1.playerturn(sectionArray);
				active = 2;
				count += 1;
			}
			if (count == 2) {
				for (int i = 0; i < 13; i++) {
					sectionArray[i].sethasattacked(0);//resets hasattacked for all nodes
					if (sectionArray[i].getownership() == 'G') {//adds +1 attack to all Grey sections
						sectionArray[i].setattackDice(sectionArray[i].getattackDice() + 1);
					}
				}
				if (sectionArray[0].getownership() == 'B') {
					gamenotover = 1;
					cout << "Player2 has won!" << endl;
				}

				count = 0;
			}

			if (active == 2) {
				cout << "Player 2's turn." << endl;
				player2.playerturn(sectionArray);
				active = 1;
				count += 1;
			}
			if (count == 2) {
				for (int i = 0; i < 13; i++) {
					sectionArray[i].sethasattacked(0);//resets hasattacked for all nodes
					if (sectionArray[i].getownership() == 'G') {//adds +1 attack to all Grey sections
						sectionArray[i].setattackDice(sectionArray[i].getattackDice() + 1);
					}
				}
				if (sectionArray[12].getownership() == 'R') {
					gamenotover = 1;
					cout << "Player1 has won!" << endl;
				}

				count = 0;
			}


		}
	}

	return 0;
}



